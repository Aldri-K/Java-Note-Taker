/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coursework;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToolBar;

/**
 *
 * @author ak0929a
 */
public class Coursework extends JFrame implements ActionListener, KeyListener {

        JPanel pnl = new JPanel (new BorderLayout());
        JTextArea txtNewNote = new JTextArea();
        JTextArea txtDisplayNotes = new JTextArea();
        ArrayList <String> note = new ArrayList<>();
        ArrayList<String> course = new ArrayList<>();
        
            
        
        Note nte = new Note();
        NoteStats nStats = new NoteStats();
        
       JTextField search = new JTextField();

        
        JComboBox courseList = new JComboBox();
        String crse = "";
        AllNotes allNotes = new AllNotes();
        CommonCode cc = new CommonCode();
        
        JFrame display = new JFrame("Sentence Display");
        JPanel pnl2 = new JPanel (new BorderLayout());
        JTextArea txtDisplayComments = new JTextArea();
    
            
        WordSearch ws = new WordSearch();
        
        WordRecursion wr = new WordRecursion();
    ArrayList<String> comment = new ArrayList<>();
    ArrayList<Integer> results = new ArrayList<>();
    String searchterm;
    String com = "";
                     
        
    public static void main(String[] args) {
                

        Coursework prg = new Coursework();
        
    }
    
    public Coursework(){
        model();
        view();
        controller();
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if("NewNote".equals(ae.getActionCommand())){
            nte.setNote(txtNewNote.getText());
            addNote(txtNewNote.getText());
            txtNewNote.setText("");
        }

        
        if("Course".equals(ae.getActionCommand())){
            crse = courseList.getSelectedItem().toString();
            System.out.println(crse);
        }
        
        if("Exit".equals(ae.getActionCommand())){
            System.exit(0);
        }
        
                if ("NewComment".equals(ae.getActionCommand())) {
            com = JOptionPane.showInputDialog(null, "Enter a sentence:");

        }

        if ("DisplayComments".equals(ae.getActionCommand())) {
            display.setVisible(true);
            
                
                txtDisplayComments.setText(com + "\n" + "Search term: " + searchterm + "\n" + "Your search term occurs " + results.size() + " times.");
            
        }

        if ("SearchComments".equals(ae.getActionCommand())) {

            searchterm = JOptionPane.showInputDialog(null, "What word would you like to search for?");
            comment = ws.SplitString(com);
            results = ws.searchArrayList(comment, searchterm);

        }
        
        
        if("AddCourse".equals(ae.getActionCommand())){
            String courseName = JOptionPane.showInputDialog("Enter the name of the new course:");
            System.out.println(courseName);
            try {
                addCourse(courseName);
            } catch (IOException ex) {

            }
            
        }
        
        if("AmendCourse".equals(ae.getActionCommand())){
            JOptionPane.showMessageDialog(null, "Not Coded Yet");
        }
        
        if("DeleteCourse".equals(ae.getActionCommand())){
            JOptionPane.showMessageDialog(null, "Not Coded Yet");
        }
        

        
        if("WordSearch".equals(ae.getActionCommand())){
            
            searchterm = JOptionPane.showInputDialog(null, "What word would you like to search for in " + crse + "?");
            int results = wr.WordFind(searchterm,crse);
            JOptionPane.showMessageDialog(null,"This word occurs " + results + " times in course, " + crse + ".");
            
        }
        
        if ("Display Stats".equals(ae.getActionCommand())) { 
            wr.nStats(crse);
        
        }
        

    }

    @Override
    public void keyTyped(KeyEvent e) {
        System.out.println("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyPressed(KeyEvent e) {
        System.out.println("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyReleased(KeyEvent e) {
        System.out.println("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void model() {
        
        course = cc.readTextFile("Courses.txt");
 
        crse = course.get(0);
        

        
        
    }

    private void view() {
        
        Font fnt = new Font ("Georgia", Font.PLAIN, 24);
        
    JPanel pnlTop = new JPanel();
        JMenuBar menuBar = new JMenuBar();
        JMenu note = new JMenu();
    JMenu crseMenu = new JMenu();
    JMenu searchMenu = new JMenu();
        
    // Task 3 Menat Pink - 000988350
    JOptionPane.showMessageDialog(null, "Modules are missing notes");
    //Menat Pink
        note = new JMenu("Note");
        note.setToolTipText("Note tasks");
        note.setFont(fnt);
        
        note.add(makeMenuItem("New", "NewNote","Create a new note.", fnt));
        
        
        
        crseMenu = new JMenu("Course Options");
         crseMenu.setToolTipText("Course tasks");
         crseMenu.setFont(fnt);
         
         searchMenu = new JMenu("Search Options");
         searchMenu.setToolTipText("Search tasks");
         searchMenu.setFont(fnt);
         
        crseMenu.add(makeMenuItem("Add Course", "AddCourse","Create a new course.", fnt));
        crseMenu.addSeparator();
        crseMenu.add(makeMenuItem("Amend Course", "AmendCourse","A course.", fnt));
        crseMenu.addSeparator();
        crseMenu.add(makeMenuItem("Delete Course", "DeleteCourse","Delete a new course.", fnt));
        
        JMenu comment = new JMenu("Comment Options");
        comment.setToolTipText("Comments");
        comment.setFont(fnt);

        comment.add(makeMenuItem("New", "NewComment", "Create a new comment.", fnt));
        comment.addSeparator();
        comment.add(makeMenuItem("Display", "DisplayComments", "Display all the comments", fnt));
        comment.addSeparator();
        comment.add(makeMenuItem("Search", "SearchComments", "Search all the comments", fnt));
        
       searchMenu.add(makeMenuItem("Word", "WordSearch", "Search for word in notes.", fnt));

        
        menuBar.add(note);
        menuBar.add(crseMenu);
        menuBar.add(comment);
        menuBar.add(searchMenu);
        
        
        menuBar.add (makeMenuItem("Display Stats","Display Stats","Display Stats",fnt));
        
        menuBar.add (makeMenuItem("Exit","Exit","Close this program.",fnt));
        
        
        
        for (String crse : course) {
            courseList.addItem(crse);
        }
        
         
        
       courseList.setFont(fnt);
       courseList.setMaximumSize(courseList.getPreferredSize());
       courseList.addActionListener(this);
       courseList.setActionCommand("Course");
       menuBar.add(courseList);
        
        this.setJMenuBar(menuBar);
        
        JToolBar toolBar = new JToolBar();
        // Setting up the ButtonBar
        JButton button = null;
        button = makeButton("Create", "NewNote", "Create a new note.","New");
        toolBar.add(button);

        toolBar.addSeparator();
        button = makeButton("exit", "Exit", "Exit from this program.", "Exit");
        toolBar.add(button);
        
        toolBar.addSeparator();
        
        add(toolBar, BorderLayout.NORTH);
        
        JPanel pnlWest = new JPanel();
        pnlWest.setLayout(new BoxLayout(pnlWest,BoxLayout.Y_AXIS));
        pnlWest.setBorder(BorderFactory.createLineBorder(Color.black));
        
        txtNewNote.setFont(fnt);
        pnlWest.add(txtNewNote);
        
        JButton btnAddNote = new JButton("Add note");
        btnAddNote.setActionCommand("NewNote");
        btnAddNote.addActionListener(this);
        pnlWest.add(btnAddNote);
        
        add(pnlWest,BorderLayout.WEST);
        
        JPanel cen = new JPanel();
        cen.setLayout(new BoxLayout(cen, BoxLayout.Y_AXIS));
        cen.setBorder(BorderFactory.createLineBorder(Color.black));
        txtDisplayNotes.setFont(fnt);
        cen.add(txtDisplayNotes);
        
        add(cen,BorderLayout.CENTER);
                        
        JMenuBar menuBar2 = new JMenuBar();
        pnl2.setLayout(new BoxLayout(pnl2, BoxLayout.Y_AXIS));
        pnl2.setBorder(BorderFactory.createLineBorder(Color.black));
        pnl2.add(menuBar2);
        pnl2.add(txtDisplayComments);
        
        display.add(pnl2);
        txtDisplayComments.setFont(fnt);
        display.setExtendedState(JFrame.MAXIMIZED_BOTH);
        
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setTitle("Coursework - Aldri Koci");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        
    }

    private void controller() {
        addAllNotes();
    }
    
        
    protected JButton makeButton(String imageName,String actionCommand, String toolTipText, String altText) {
        //Create and initialize the button.
        JButton button = new JButton();
        button.setToolTipText(toolTipText);
        button.setActionCommand(actionCommand);
        button.addActionListener(this);
        
        //Look for the image.
        String imgLocation = System.getProperty("user.dir") + "\\icons\\" + imageName + ".png";

        File fle = new File(imgLocation);

        if (fle.exists() && !fle.isDirectory()) {
        // image found
        Icon img;
        img = new ImageIcon(imgLocation);
        button.setIcon(img);
        } 

        else {
        // image NOT found
        button.setText(altText);
        System.err.println("Resource not found: " + imgLocation);
        }
        return button;
            }
    
    
    private void addCourse(String coursename) throws IOException{
        course = cc.readTextFile("Courses.txt");
        course.add(coursename);
                
        cc.writeTextFile("Courses.Txt", course);
        courseList.addItem ("" + coursename);
        
    }
    
    private void addNote(String text) {
         allNotes.addNote(allNotes.getMaxID(), crse, text);
 addAllNotes();
     }
    
    
    private void addAllNotes() {
     
       String txtNotes = "";
       
    for (Note n : allNotes.allNotes) {
        txtNotes += n.note + "\n";
    }
       
    txtDisplayNotes.setText(txtNotes);
        
    }   
    
   protected JMenuItem makeMenuItem(String txt, String actionCommand, String toolTipText, Font fnt){
    
       JMenuItem mnuItem = new JMenuItem();
       mnuItem.setText(txt);
       mnuItem.setActionCommand(actionCommand);
       mnuItem.setToolTipText(toolTipText);
       mnuItem.setFont(fnt);
       mnuItem.addActionListener(this);
       
       return mnuItem;
   }
   

    
    
}

