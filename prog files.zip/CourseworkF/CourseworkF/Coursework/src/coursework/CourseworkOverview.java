/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coursework;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;

/**
 *
 * @author ak0929a
 */
public class CourseworkOverview extends JFrame implements ActionListener, KeyListener{
        
         Note Note = new Note();
         
        JFrame display = new JFrame("Coursework Display");
        
        JPanel coursework = new JPanel();
        JTextArea txtNewNote = new JTextArea();
        JTextArea txtDisplaySpec = new JTextArea(1,1);
        JTextArea txtDisplayNotes = new JTextArea(1,1);
        ArrayList <String> note = new ArrayList<>();
        ArrayList<String> course = new ArrayList<>();
    public void main(){
        
        view();
     
    }
    
    private void view() {
            
       JPanel pnlWest = new JPanel();
        pnlWest.setLayout(new BoxLayout(pnlWest,BoxLayout.Y_AXIS));
        pnlWest.setBorder(BorderFactory.createLineBorder(Color.black));
        
        pnlWest.add(txtNewNote);
        
        JButton btnAddNote = new JButton("Add note");
        btnAddNote.setActionCommand("NewNote");
        btnAddNote.addActionListener(this);
        pnlWest.add(btnAddNote);
        
        add(pnlWest,BorderLayout.WEST);
        
        display.add(pnlWest);
        
        JPanel cen = new JPanel();
        cen.setLayout(new BoxLayout(cen, BoxLayout.Y_AXIS));
        cen.setBorder(BorderFactory.createLineBorder(Color.black));
        cen.add(txtDisplaySpec);
        
        add(cen,BorderLayout.CENTER);
       
        
        
       display.setExtendedState(JFrame.MAXIMIZED_BOTH);
       display.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       display.setVisible(true);

            
        }
    
    
      public void actionPerformed(ActionEvent ae) {
        if("NewNote".equals(ae.getActionCommand())){
            Note.setNote(txtNewNote.getText());
            txtNewNote.setText("");
        }
      }

    @Override
    public void keyTyped(KeyEvent e) {
 System.out.println("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyPressed(KeyEvent e) {
 System.out.println("Not supported yet."); //To change body of generated methods, choose Tools | Templates.    }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        System.out.println("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
      
}
