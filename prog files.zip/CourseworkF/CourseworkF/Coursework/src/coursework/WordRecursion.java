/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coursework;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author ak0929a
 */
public class WordRecursion extends CommonCode {
    
    
    WordSearch wordS = new WordSearch();
    AllNotes Note = new AllNotes();
    
    public int WordFind (String search, String course){
        ArrayList<String> sentence = new ArrayList();
        
        sentence = readCourseNotes(appDir + "\\Notes.txt", course);
         int count = 0;
         int total = 0;
         
        total = recursion(count, total, sentence, search);
        return total;
            }

    public int recursion(int count,int total, ArrayList<String> sentence, String search){
        if (count < sentence.size()) {
              ArrayList<String> split = new ArrayList<String>(Arrays.asList(sentence.get(count).split("\t")));
              ArrayList<String> split2 = new ArrayList<String>(Arrays.asList(split.get(3).split(" ")));

              ArrayList<Integer> find = new ArrayList<Integer>();

            find = wordS.searchArrayList(split2, search);

            total = total + find.size();
            count += 1;
            total = recursion(count, total, sentence, search);
            }
        return total;
    }
   
    
    
   public ArrayList<String> readCourseNotes(String fileName, String course) {
    ArrayList file = new ArrayList();
    String line;

   if ((fileName == null) || (fileName.equals(""))) {
    System.out.println("No file name specified.");
    } else {
    try {
    BufferedReader in = new BufferedReader(new FileReader(fileName));

    if (!in.ready()) {
    throw new IOException();
    }

    while ((line = in.readLine()) != null) {
        
        ArrayList<String> split = new ArrayList<String>(Arrays.asList(line.split("\t")));
        ArrayList<Integer> find = new ArrayList<Integer>();
        
        find = wordS.searchArrayList(split, course);
        
       if (find.size()>0){
           
           file.add(line);
       }
        
    }
    in.close();
    } catch (IOException e) {
    System.out.println(e);
    file.add("File not found");
    }
    }
        return file;
    
        
        
   } 
   
   //task 2 Aldri Koci ak0929a
        public void nStats(String course){
            ArrayList<String> sentence = new ArrayList();
            
            sentence = readCourseNotes(appDir + "\\Notes.txt", course);
            ArrayList<String> CourseCon = new ArrayList();
            CourseCon = readCourseNotes(appDir + "\\Courses.txt", course);
            System.out.println("There are " + sentence.size() + " notes");
            System.out.println("First note taken was , '" + sentence.get(0) + "'");
            System.out.println("First note taken was , '" + sentence.get(sentence.size()-1) + "'");
            
            
            ArrayList<String> split = new ArrayList<String>(Arrays.asList(CourseCon.get(0).split("|")));
            System.out.println("There are " + split.size() + " courses");

            
        }
   
   
}


