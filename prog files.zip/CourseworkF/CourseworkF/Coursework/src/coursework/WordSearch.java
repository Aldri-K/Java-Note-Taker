/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coursework;

import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author ak0929a
 */
public class WordSearch extends CommonCode {

    ArrayList<Integer> searchArrayList(ArrayList<String> sentence, String searchterm) {
        int count = 0;
        int compVal;
        ArrayList<Integer> match = new ArrayList<Integer>();

        while (count < sentence.size()) {
            compVal = sentence.get(count).compareToIgnoreCase(searchterm);
            if (compVal == 0) {
                match.add(count);
            }
            count += 1;
        }
        return match;
    }

    ArrayList<String> SplitString(String sentence) {
        ArrayList<String> split = new ArrayList<String>(Arrays.asList(sentence.split(" ")));
        return split;

    }

}
